$(document).ready(function() {
    $('#clickme').click(function() {
        alert(2)
        console.log("rady")
    })
})